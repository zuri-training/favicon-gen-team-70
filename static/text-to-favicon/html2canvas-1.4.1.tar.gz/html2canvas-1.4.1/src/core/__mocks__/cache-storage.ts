export class CacheStorage {}
